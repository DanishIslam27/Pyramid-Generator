#include <stdio.h>
#include <cs50.h>

int main(void)
{
    printf("Choose a height between 1 and 8.\n");
    
    int height;
    do
    {
        height = get_int("Height: ");
    }
    while (height > 8 || height < 1);
    
    for (int i = 1; i <= height; i++)
    {
        for (int space = 1; space <= height - i; space++)
        {
            printf(" ");
        }
        for (int blocks = 0; blocks < i; blocks++)
        {
            printf("#");
        }
        printf("  ");
        for (int blocks = 0; blocks < i; blocks++)
        {
            printf("#");
        }
        printf("\n");
    }
}